package com.review1.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.review1.model.Pharmacymodel;
import com.review1.repository.Pharmacyrepo;

@Service
public class Pharmacyservice {
	@Autowired
	Pharmacyrepo pharmrepo;
	public List<Pharmacymodel>getAllPharmacy()
	{
		return pharmrepo.findAll();
	}
	public Pharmacymodel savepharmacymodel(Pharmacymodel p)
	{ 
		return pharmrepo.save(p);
	}
	public Pharmacymodel updatePharmacymodel(Pharmacymodel p)
	{
		return pharmrepo.save(p);
		
	}
	public String deletePharmacymodel(int id)
	{
		pharmrepo.deleteById(id);
		return "Deleted Successfull";
	}
	public Pharmacymodel getPharmacymodel(int id)
	{
		return pharmrepo.findById(id).get();
	}
	public List<Pharmacymodel> pharmacysort(String cost) {
		 return pharmrepo.findAll(Sort.by(cost).ascending());
	}
	public List<Pharmacymodel> pharmacysort1(String cost) {
		 return pharmrepo.findAll(Sort.by(cost).descending());
	}
	public List<Pharmacymodel> getPharmacy(@PathVariable int offset,@PathVariable int pagesize) {
		Page <Pharmacymodel> page=pharmrepo.findAll(PageRequest.of(offset, pagesize));
		return page.getContent();
	}
	public List<Pharmacymodel> getPharmacysort(int offset, int pagesize, String field) {
		PageRequest paging=PageRequest.of(offset, pagesize,Sort.by(field));
		Page<Pharmacymodel>page=pharmrepo.findAll(paging);
		return page.getContent() ;
	}
}
