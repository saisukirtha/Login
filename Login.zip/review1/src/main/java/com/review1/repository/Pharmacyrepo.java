package com.review1.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.review1.model.Pharmacymodel;
public interface Pharmacyrepo extends JpaRepository<Pharmacymodel,Integer> {

}
