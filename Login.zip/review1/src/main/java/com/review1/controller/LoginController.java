package com.review1.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.review1.model.LoginModel;
import com.review1.service.LoginService;


@RestController
public class LoginController {
	@Autowired
	LoginService usrService;
	@PostMapping("/addUser")
	public  LoginModel getdata (@RequestBody LoginModel u)
	{
		return usrService.savedata1(u);
	}
	@PostMapping("/checkLogin")
	public String validateUser(@RequestBody LoginModel u)
	{
		System.out.println(u.getUsername());
		return usrService.validateUser(u.getUsername(),u.getPassword());
	}
}
