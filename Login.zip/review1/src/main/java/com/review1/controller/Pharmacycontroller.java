package com.review1.controller;                                                                                      

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.review1.model.Pharmacymodel;
import com.review1.service.Pharmacyservice;

@RestController
public class Pharmacycontroller {
	@Autowired
	Pharmacyservice pharmservice;
	
	@GetMapping(value="/fetchPhaarmacymodel")
	public List<Pharmacymodel>getAllPharmacymodel() 
	{
		return pharmservice.getAllPharmacy();
	}
	@PostMapping(value="/savePharmacymodel")
	public Pharmacymodel savePharmacymodel(@RequestBody Pharmacymodel p)
	{
		return pharmservice.savepharmacymodel(p);
	}
	@PutMapping(value="/updatePharmacymodel")
	public Pharmacymodel updatePharmacymodel(@RequestBody Pharmacymodel p)
	{
		return pharmservice.savepharmacymodel(p);
	}
	@DeleteMapping("/deletePharmacymodel/{id}")
	public String deletePharmacymodel(@PathVariable("id")int id)
	{
		return pharmservice.deletePharmacymodel(id);
	}
	@GetMapping(value="/getPharmacymodel/{id}")
	public Pharmacymodel getPharmacymodel(@PathVariable("id")int id)
	{
		return pharmservice.getPharmacymodel(id);
	}
	@GetMapping(value="/sortPharmacy/{sort}")
	public List<Pharmacymodel> sortPharmacy(@PathVariable("sort") String cost)
	{
		return pharmservice.pharmacysort(cost);
	}
	@GetMapping(value="/sortPharmacy1/{sort}")
	public List<Pharmacymodel> sortPharmacy1(@PathVariable("sort") String cost)
{
		return pharmservice.pharmacysort1(cost);
	}
	@GetMapping(value="pagePharmacy/{offset}/{pagesize}")
	public List<Pharmacymodel> getPharmacydetails(@PathVariable int offset,@PathVariable int pagesize)
	{
		return pharmservice.getPharmacy(offset,pagesize);
	}
	@GetMapping("/pagingPharmacy/{offset}/{pagesize}/{field}")
	public List<Pharmacymodel>getPharm(@PathVariable int offset,@PathVariable int pagesize,@PathVariable String field)
	{
		return pharmservice.getPharmacysort(offset,pagesize,field);
	}
}
